
#ifndef __MOTOR_H
#define __MOTOR_H

#include "stm32f10x.h"



void MOTOR_GPIO_Config(void);
void Motor_PWM_Init(u16 arr, u16 psc, u16 arr2, u16 psc2 );

#endif
